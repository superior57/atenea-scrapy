"""
General IaC constants
"""
PARAMETER_OVERRIDES = "parameter_overrides"
GLOBAL_PARAMETER_OVERRIDES = "global_parameter_overrides"
